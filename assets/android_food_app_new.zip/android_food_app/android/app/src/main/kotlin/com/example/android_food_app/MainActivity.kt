package com.example.android_food_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
